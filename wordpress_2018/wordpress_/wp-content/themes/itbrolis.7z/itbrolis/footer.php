
		<?php wp_footer();?>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        Small text for footer
                    </div>
                </div>
            </div>
        </footer>

	</body>
</html>